
"use strict";

let GetSerial = require('./GetSerial.js')

module.exports = {
  GetSerial: GetSerial,
};
